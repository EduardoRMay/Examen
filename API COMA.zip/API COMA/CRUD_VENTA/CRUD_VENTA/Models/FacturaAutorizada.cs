﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD_VENTA.Models
{
    public class FacturaAutorizada
    {
        public string Folio { get; set; }
        public int Saldo { get; set; }
        public DateTime FechaFacturacion { get; set; }
        public DateTime FechaCreacion { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }

    }
}
