﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRUD_VENTA.Models
{
    public partial class Factura
    {
        public int Id { get; set; }
        public int IdUsuario { get; set; }
        public string Folio { get; set; }
        public int Saldo { get; set; }
        public DateTime FechaFacturacion { get; set; }
        public DateTime FechaCreacion { get; set; }

        public virtual Usuario IdUsuarioNavigation { get; set; }
    }
}
