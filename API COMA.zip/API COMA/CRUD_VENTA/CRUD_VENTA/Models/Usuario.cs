﻿using System;
using System.Collections.Generic;

#nullable disable

namespace CRUD_VENTA.Models
{
    public partial class Usuario
    {
        public Usuario()
        {
            Facturas = new HashSet<Factura>();
        }

        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public int Edad { get; set; }
        public string CorreoElectronico { get; set; }
        public string TipoUsuario { get; set; }

        public virtual ICollection<Factura> Facturas { get; set; }
    }
}
