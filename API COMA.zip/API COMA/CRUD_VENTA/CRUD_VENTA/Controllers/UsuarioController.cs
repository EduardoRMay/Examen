﻿using CRUD_VENTA.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD_VENTA.Controllers
{
    [Route("ventas/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {

        [HttpGet]
        [Route("Listacliente")]
        public async Task<IActionResult> getall()
        {

            using (var db = new Models.VentasContext())
            {
                List<Models.Usuario> usuarios = await db.Usuarios.Where(x => x.TipoUsuario == "cliente").ToListAsync();

                return StatusCode(StatusCodes.Status200OK, usuarios);
            }
        }

        [HttpPost]
        [Route("Crear")]
        public async Task<IActionResult> create([FromBody] Models.Usuario request)
        {

            using (var db = new Models.VentasContext())
            {
               await db.Usuarios.AddAsync(request);
               await db.SaveChangesAsync();

                return StatusCode(StatusCodes.Status200OK, "ok");
            }

        }
        
        [HttpDelete]
        [Route("Eliminar/{id:int}")]
        public async Task<IActionResult> delete(int id)
        {
            using (var db = new Models.VentasContext())
            {
                Models.Usuario usuario = db.Usuarios.Find(id);
                db.Usuarios.Remove(usuario);
                await db.SaveChangesAsync();

                return StatusCode(StatusCodes.Status200OK, "ok");
            }
        }



    }
}
