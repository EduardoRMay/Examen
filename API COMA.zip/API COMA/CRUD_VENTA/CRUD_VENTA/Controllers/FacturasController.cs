﻿using CRUD_VENTA.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CRUD_VENTA.Controllers
{
    [Route("ventas/[controller]")]
    [ApiController]
    public class FacturasController : ControllerBase
    {
        [HttpGet]
        [Route("ListaFactura")]
        public IEnumerable<FacturaAutorizada> getAllListasAutorizadas()
        {
            
            using(var db = new VentasContext())
            {
                var query = from f in db.Facturas
                            join u in db.Usuarios on f.IdUsuario equals u.Id where (u.TipoUsuario == "gerente")
                            select new FacturaAutorizada
                            {
                                Nombre = u.Nombre,
                                Apellido = u.Apellido,
                                Saldo = f.Saldo,
                                Folio = f.Folio,
                                FechaCreacion = f.FechaCreacion,
                                FechaFacturacion = f.FechaFacturacion
                            };
                return query.ToList();
            }         
        }
        [HttpPost]
        [Route("crearFactura")]

        public async Task<IActionResult> create([FromBody] Models.Factura request)
        {

            using (var db = new Models.VentasContext())
            {
                await db.Facturas.AddAsync(request);
                await db.SaveChangesAsync();

                return StatusCode(StatusCodes.Status200OK, "ok");
            }

        }


        [HttpDelete]
        [Route("Eliminar/{id:int}")]
        public async Task<IActionResult> delete(int id)
        {
            using (var db = new Models.VentasContext())
            {
                Models.Factura factura = db.Facturas.Find(id);
                db.Facturas.Remove(factura);
                await db.SaveChangesAsync();

                return StatusCode(StatusCodes.Status200OK, "ok");
            }
        }


    }
}
